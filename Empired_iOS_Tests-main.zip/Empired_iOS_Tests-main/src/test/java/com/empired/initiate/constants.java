package com.empired.initiate;
public class constants {
	
	
	//Vansah Project Level Configuration
	public static String url = "https://api.vansah.app/";
	public static String release = "";
	public static String environment = "";
	public static String testcase="287";
	public static String issue_key = "GDS-336";
	//public static String project_identifier = "230b1828-6ed2-11ec-8731-dec8a00a0c66";



}