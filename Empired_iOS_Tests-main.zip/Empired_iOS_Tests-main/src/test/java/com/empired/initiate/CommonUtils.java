package com.empired.initiate;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;

// TODO: Auto-generated Javadoc



public class CommonUtils{

	static int maxTimeout = 60;
	
	//******** Synthetics support variables *******
	private static long startTime;
	private static long endTime;
	private static Long tempResponse;
	protected static String responseTime = "";
	protected static String responseStatus = "";
	static String startTimeFormatted;
	static String stopTimeFormatted;
	//static vansahjira resultapi;
	
		
	public static void synthetics(String case_key,String typeOfCounter, String testStep, String scenario, long threshold) throws Exception {
		
		
		if(typeOfCounter.equals("start")) {
			System.out.println("########## Counter has started... ############## ");
			startTimeFormatted = getTime();
			startTime = System.nanoTime();	
			
		}
		
		if(typeOfCounter.equals("stop")) {
			
			String result;
			stopTimeFormatted = getTime();	
			endTime = System.nanoTime();
			tempResponse = Long.valueOf(endTime - startTime);
			Double response = Double.valueOf(tempResponse.longValue() / 1000000.0);
			responseTime = String.valueOf(response);
			//Determine if response time is above or below threshold
			if(response > threshold) {
				result = "FAIL";
				
			}else {
				result = "PASS";
			}
			responseStatus=result;
			System.out.println("########### Counter has stopped! Response time was: " + responseTime);
		   
		    String formattedDate = getDate();
		    String formattedTime = getTime();
		    
			//File path
			String path = System.getProperty("user.dir") + "\\synthetics\\results.xlsx";

			//Write Results to the file
			writeToExcel(case_key, testStep, scenario, responseTime, formattedDate, formattedTime, startTimeFormatted, stopTimeFormatted, result, path);
		} 
	}

	//check
	public static void writeToExcel(String case_key, String testStep, String scenario, String responseTime, String formattedDate, String formattedTime, String startTimeFormatted, String stopTimeFormatted, String result, String path) throws Exception{
		//resultapi = new vansahjira();
		
		
//		resultapi.add_test_run(case_key, constants.release, constants.environment, constants.issue_key, "", "", "");
//		resultapi.add_test_log(2,startTimeFormatted , 1, 0, constants.issue_key, "jirahost", false, driver,constants.project_identifier);
//		resultapi.add_test_log(2,stopTimeFormatted , 2, 0, constants.issue_key, "jirahost", false, driver ,constants.project_identifier);
		
//		if(result == "FAIL") {
//			
//			resultapi.add_test_log(1,responseTime , 3, 0, constants.issue_key, "jirahost", false, driver ,constants.project_identifier);
//			
//		}
//		else if(result == "PASS") {
//
//			resultapi.add_test_log(2,responseTime , 3, 0, constants.issue_key, "jirahost", false, driver ,constants.project_identifier);
//		}
		File src = new File(path);
        
		if(src.exists()) {
			System.out.println("### Synthetics File exists. Using existing.");
		    Workbook workbook = new XSSFWorkbook(new FileInputStream(path));
		    Sheet sheet = workbook.getSheet("results");
		    int lastRow = sheet.getLastRowNum();
		    System.out.println("Last rows is "+ lastRow);
		    int nextLine = lastRow + 1;
		    Row row = sheet.createRow(nextLine);
		    row = sheet.getRow(nextLine);
		    Cell cell =  row.getCell(0);
		    
		    //Create 8 colums
		    for(int i=0;i<=7;i++) {
		    	 cell = row.createCell(i);
		    }
		   
		    cell = row.getCell(0);cell.setCellValue(scenario);
		    cell = row.getCell(1);cell.setCellValue(formattedDate);
		    cell = row.getCell(2);cell.setCellValue(formattedTime);
		    cell = row.getCell(3);cell.setCellValue(testStep);
		    cell = row.getCell(4);cell.setCellValue(startTimeFormatted);
		    cell = row.getCell(5);cell.setCellValue(stopTimeFormatted);
		    cell = row.getCell(6);cell.setCellValue(responseTime);
		    cell = row.getCell(7);cell.setCellValue(result);
		    
		    
//		    FileWriter fstream = new FileWriter(path);
//		    BufferedWriter out = new BufferedWriter(fstream);
//		    out.write(workbook);
//		    
            FileOutputStream fileOut = new FileOutputStream(path);
            workbook.write(fileOut);
            fileOut.close();
            workbook.close();
		    
		    
		}else {
			System.out.println("Synthetics File doesn't exist. Creating one.");
			//Create a Workbook
	        Workbook workbook = new XSSFWorkbook(); // new HSSFWorkbook() for generating `.xlsx` file
	        //Create a Sheet
	        Sheet sheet = workbook.createSheet("results");
	        //Create a Row
	        Row headerRow = sheet.createRow(0);
	        
	        //Create Header cell
            Cell cell = headerRow.createCell(0);cell.setCellValue("Scenario");
            cell = headerRow.createCell(1);cell.setCellValue("Date");
            cell = headerRow.createCell(2);cell.setCellValue("Timestamp");
            cell = headerRow.createCell(3);cell.setCellValue("Step");
            cell = headerRow.createCell(4);cell.setCellValue("Start Time");
            cell = headerRow.createCell(5);cell.setCellValue("Stop Time");
            cell = headerRow.createCell(6);cell.setCellValue("Response Time");
            cell = headerRow.createCell(7);cell.setCellValue("Result");
           
            int rowNum = 1;
            
            Row row = sheet.createRow(rowNum);
            row.createCell(0).setCellValue(scenario);
            row.createCell(1).setCellValue(formattedDate);
            row.createCell(2).setCellValue(formattedTime);  
            row.createCell(3).setCellValue(testStep);
            row.createCell(4).setCellValue(startTimeFormatted);
            row.createCell(5).setCellValue(stopTimeFormatted);
            row.createCell(6).setCellValue(responseTime);
            row.createCell(7).setCellValue(result);
            
            
   		 	//Write the output to a file
            FileOutputStream fileOut = new FileOutputStream(path);
            workbook.write(fileOut);
            fileOut.close();

            //Closing the workbook
            workbook.close();

		}
		
		
	}
	
	public static String getTime() {
		
		LocalTime myTimeObj = LocalTime.now();
	    DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("HH:mm:ss");
	    String formattedTime = myTimeObj.format(myFormatObj);
	    //System.out.println("After formatting: " + formattedTime);
		return formattedTime;
		
	}
	
	public static String getDate() {
		
		LocalDate myDateObj = LocalDate.now();
	    DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	    String formattedDate = myDateObj.format(myFormatObj);
	    //System.out.println("After formatting: " + formattedDate);
		return formattedDate;
		
	}
	
}
