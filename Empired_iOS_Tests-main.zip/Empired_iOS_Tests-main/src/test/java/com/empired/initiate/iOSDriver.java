package com.empired.initiate;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.empired.epatests.C35;
import com.empired.epatests.C36;
import com.empired.epatests.C7;
import com.empired.epatests.LoginPage;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;

import io.appium.java_client.MobileBy;
import io.appium.java_client.ios.IOSElement;


public class iOSDriver extends BrowserStackTestNGTest {
//ios_tests
	String record="L8N-553379-F8L";
  @Test
  public void main_driver_ios() throws Exception {
    
	  	
	  		LoginPage login =new LoginPage(driver);
	  		C7 c7 = new C7(driver);
	  		C35 c35 = new C35(driver);
	  		C36 c36 = new C36(driver);
	  		
	  		login.measureResponseTimeLogin("C1 - Driver Login_IOS",System.getenv("DRIVER_MAIL"),System.getenv("DRIVER_PASS"));
	  		c7.measureResponseTimeSearch("C7 - PPR2 Driver Search_IOS ", record,false);
	  		c35.measureResponseTimeSearch("C35 - PPR2 Driver Pickup_IOS ", record);
	  		c7.measureResponseTimeSearch("C36 - PPR2 Driver_drop_Off_Search_IOS ", record,true);
	  		c36.measureResponseTimeSearch("C36 - PPR2 Driver Drop_waste_IOS", record);
	  		
	  		
	  
	  
  }
}
