package com.empired.initiate;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.empired.epatests.C10;
import com.empired.epatests.C35;
import com.empired.epatests.C36;
import com.empired.epatests.C7;
import com.empired.epatests.LoginPage;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;

import io.appium.java_client.MobileBy;
import io.appium.java_client.ios.IOSElement;


public class iOSReceiver extends BrowserStackTestNGTest {
//ios_tests
	String record="L8N-553379-F8L";
  @Test
  public void main_receiver_ios() throws Exception {
    
	  	
	  		LoginPage login =new LoginPage(driver);
	  		C7 c7 = new C7(driver);
	  		C10 c10= new C10(driver);
	  		login.measureResponseTimeLogin("C1 - PPR2 Receiver Login_IOS ",System.getenv("SITE_RECEIVER_MAIL"),System.getenv("SITE_RECEIVER_PASS"));
	  		c7.measureResponseTimeSearch("C7 - PPR2 Receiver Search_IOS ", record,false);
	  		c10.measureResponseTimeSearch("C10 - PPR2 Receiver receive-waste_IOS ", record);
	  		
	  	   // 	
	  	   // 	c7.measureResponseTimeSearch("PPR2 Receiver Search_Android ", "B0Y-540105-Q8R");//"B1G-1900-F3D");   //data should be in Assigned state/not in Add info
	  		
	  		
	  		
	  
	  
  }
}
