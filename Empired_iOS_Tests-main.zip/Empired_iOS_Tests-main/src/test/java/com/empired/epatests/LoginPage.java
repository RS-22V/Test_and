package com.empired.epatests;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.empired.initiate.CommonUtils;
import com.empired.initiate.constants;
import com.empired.initiate.vansahjira;

import io.appium.java_client.MobileBy;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.ios.IOSElement;

public class LoginPage extends CommonUtils{


	private WebDriver driver;
	private WebDriverWait wait ;
	vansahjira vj= new vansahjira();

	By email_field = By.xpath("//XCUIElementTypeTextField[@label=\"Email address\"]");
	By password_field = By.xpath("//XCUIElementTypeSecureTextField");
	By login_button = By.xpath("//XCUIElementTypeButton[@name='Sign in']");
	By continue_app = By.xpath("//XCUIElementTypeButton[@name='Continue']");
	By allow_location = By.id("Allow While Using App");
	By password_tap = By.xpath("//XCUIElementTypeStaticText[@name='Password']");
	By sign_in_loader = By.xpath("//XCUIElementTypeStaticText[@name=\"Signing in...\"]");
	


	public void measureResponseTimeLogin(String user_role,String email, String password) throws Exception {	
		
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		vj.add_test_run(constants.testcase,null, constants.environment, constants.issue_key,"", "", "");
		IOSElement t = driver.findElement(continue_app);
		t.click();
		
		driver.findElement(allow_location).click();
		Thread.sleep(3000);
		new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(email_field)));
		IOSElement email_element = driver.findElement(email_field);
		email_element.sendKeys(email);
		IOSElement password_element = driver.findElement(password_field);
		password_element.sendKeys(password);
		driver.findElement(password_tap).click();
		Thread.sleep(2000);
		driver.findElement(login_button).click();		
		CommonUtils.synthetics("1","start", user_role, user_role, 10000);
		new WebDriverWait(driver, 60).until(ExpectedConditions.invisibilityOf(driver.findElement(sign_in_loader)));
		CommonUtils.synthetics("1","stop", user_role, user_role, 10000);
		
		System.out.println("Response value  :"+super.responseTime.valueOf(responseTime));
		 if(super.responseStatus.equalsIgnoreCase("pass")){ 
			 
			 System.out.println("### Sending Passed status to Vansah ###\n"+user_role + super.responseTime);
	    	  vj.add_test_log(2,user_role + super.responseTime,1,0,"GDS-336", "", true, driver);
	      }
	      else {
	    	  System.out.println("### Sending Failed status to Vansah ###\n"+user_role + super.responseTime);
	    	  vj.add_test_log(1,user_role + super.responseTime,1,0,"GDS-336", "", true, driver);
	      }


	}


	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}


}
