package com.empired.epatests;


import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.empired.initiate.CommonUtils;
import com.empired.initiate.constants;
import com.empired.initiate.vansahjira;


import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;

public class C36 extends CommonUtils {


	private IOSDriver<IOSElement> driver;
	vansahjira vj= new vansahjira();

	By Drop_off_waste = By.xpath("//XCUIElementTypeButton[@label='Drop off waste']");

	By Drop_off = By.xpath("//XCUIElementTypeButton[@label='Drop off']");

	By Drop_off_progress = By.xpath("//XCUIElementTypeStaticText[@label='Dropping off waste...']");

	By Drop_off_success = By.xpath("//XCUIElementTypeStaticText[@label='Waste dropped off']");

	public C36(IOSDriver<IOSElement> driver) {
		this.driver = driver;

	}
	

	@SuppressWarnings("static-access")
	public void measureResponseTimeSearch(String user_role, String waste_record_id) throws Exception {
		
		vj.add_test_run(constants.testcase,null, constants.environment, constants.issue_key,"", "", "");

		
				
		
		JavascriptExecutor js2 = (JavascriptExecutor) driver;
		HashMap<String, String> scrollObject2 = new HashMap<String, String>();
		scrollObject2.put("direction", "up");
		
		for(int i=0; i<4;i++) {
			js2.executeScript("mobile: swipe", scrollObject2);
		}
		
		
			new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(Drop_off_waste)));
			IOSElement sfieldd = driver.findElement(Drop_off_waste);
			sfieldd.click();

			
			new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(Drop_off)));

			IOSElement sbuttond = driver.findElement(Drop_off);
			sbuttond.click();

			

			CommonUtils.synthetics("1","start", user_role, user_role, 10000);
			new WebDriverWait(driver, 60).until(ExpectedConditions.invisibilityOf(driver.findElement(By.xpath("//XCUIElementTypeStaticText[@label='Dropping off waste...']"))));
			new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//XCUIElementTypeImage[@label='Success']"))));
			CommonUtils.synthetics("1","stop", user_role, user_role, 10000);
			if(super.responseStatus.equalsIgnoreCase("pass")){ 

				System.out.println("### Sending Passed status to Vansah ###\n"+user_role + super.responseTime);
				vj.add_test_log(2,user_role + super.responseTime,1,0,"GDS-336", "", true, driver);
			}
			else {
				System.out.println("### Sending Failed status to Vansah ###\n"+user_role + super.responseTime);
				vj.add_test_log(1,user_role + super.responseTime,1,0,"GDS-336", "", true, driver);
			}
		}


		


	}



