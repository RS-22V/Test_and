package com.empired.epatests;

import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.empired.initiate.CommonUtils;
import com.empired.initiate.constants;
import com.empired.initiate.vansahjira;


import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;

public class C7 extends CommonUtils {


	private IOSDriver<IOSElement> driver;

	//private WebDriverWait wait ;
	boolean DF;
	
	vansahjira vj= new vansahjira();

	By search_field = By.xpath("//XCUIElementTypeTextField[@value=\"Waste record ID\"]");


	By search_button = By.xpath("//XCUIElementTypeOther[@label='Search button']");



	By close_add_vehicle_popup = By.xpath("//XCUIElementTypeButton[@label=\"Close\"]");


	By wait_activerecord = By.xpath("//XCUIElementTypeStaticText[@value=\"Active records\"]");

	By search_progress = By.xpath("//XCUIElementTypeStaticText[@label='Searching...']"); 



	public C7(IOSDriver<IOSElement> driver) {
		this.driver = driver;

	}

	@SuppressWarnings("static-access")
	public void measureResponseTimeSearch(String user_role, String waste_record_id,boolean DF) throws Exception {
		
		
		
		if (DF==true) {
			new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(search_button)));

			IOSElement sbutton = driver.findElement(search_button);
			
			CommonUtils.synthetics("1","start", user_role,user_role, 10000);
			sbutton.click();
			new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//XCUIElementTypeStaticText[@value='"+waste_record_id+"']"))));
			CommonUtils.synthetics("1","stop", user_role, user_role, 10000);
			if(super.responseStatus.equalsIgnoreCase("pass")){ 

				System.out.println("### Sending Passed status to Vansah ###\n"+user_role + super.responseTime);
				vj.add_test_log(2,user_role + super.responseTime,1,0,"GDS-336", "", true, driver);
			}
			else {
				System.out.println("### Sending Failed status to Vansah ###\n"+user_role + super.responseTime);
				vj.add_test_log(1,user_role + super.responseTime,1,0,"GDS-336", "", true, driver);
			}
			System.out.println("Completed search operation for Drop-Off_waste -> ##Next step- C36");
			
		}
		else {
			vj.add_test_run(constants.testcase,null, constants.environment, constants.issue_key,"", "", "");


			new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(search_field)));
			IOSElement sfield = driver.findElement(search_field);
			sfield.sendKeys(waste_record_id);

			//new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(wait_activerecord)));


			new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(search_button)));

			IOSElement sbutton = driver.findElement(search_button);
			

			//		IOSElement close_popup1 = driver.findElement(close_add_vehicle_popup);
			//		close_popup1.click();//sometimes it is saying to add vehicle details


			CommonUtils.synthetics("1","start", user_role, user_role, 10000);
			sbutton.click();
			new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//XCUIElementTypeStaticText[@value='"+waste_record_id+"']"))));
			CommonUtils.synthetics("1","stop", user_role, user_role, 10000);
			if(super.responseStatus.equalsIgnoreCase("pass")){ 

				System.out.println("### Sending Passed status to Vansah ###\n"+user_role + super.responseTime);
				vj.add_test_log(2,user_role + super.responseTime,1,0,"GDS-336", "", true, driver);
			}
			else {
				System.out.println("### Sending Failed status to Vansah ###\n"+user_role + super.responseTime);
				vj.add_test_log(1,user_role + super.responseTime,1,0,"GDS-336", "", true, driver);
			}
		}


		


	}


}
