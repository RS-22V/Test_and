package com.empired.epatests;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.empired.initiate.CommonUtils;
import com.empired.initiate.constants;
import com.empired.initiate.vansahjira;

import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;

public class C10 extends CommonUtils{
	private IOSDriver<IOSElement> driver;
	//private WebDriver driver;
	private WebDriverWait wait ;
	vansahjira vj= new vansahjira();
	By Receive_button = By.xpath("//XCUIElementTypeButton[@label='Receive waste']");
	
	By Permission_site = By.xpath("//XCUIElementTypeStaticText[@label='Permission site']//parent::XCUIElementTypeOther//parent::XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther");
	
	By amount_waste = By.xpath("//XCUIElementTypeStaticText[@label='Amount of waste']//parent::XCUIElementTypeOther//parent::XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTextField");
	
	By unit_waste = By.xpath("//XCUIElementTypeStaticText[@label='Unit of waste']//parent::XCUIElementTypeOther//parent::XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeButton");
	
	By click_done = By.xpath("//XCUIElementTypeButton[@label='Done']");
	
	By click_empty_table = By.xpath("//XCUIElementTypeTable[@label='Empty list']");
	
	By click_continue = By.xpath("//XCUIElementTypeButton[@label='Continue']");
	
	By click_submit = By.xpath("//XCUIElementTypeButton[@label='Submit']");
	
	By accepting_progress = By.xpath("//XCUIElementTypeActivityIndicator[@label='In progress']");
	
	By receive_waste_success = By.xpath("//XCUIElementTypeImage[@label='Success']");

	
	public C10(IOSDriver<IOSElement> driver) {
		  this.driver = driver;
			
		}
	
	public void measureResponseTimeSearch(String user_role, String waste_record_id) throws Exception {
		
		//search_data = By.xpath("//android.widget.TextView[@text="+waste_record_id+"]");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		vj.add_test_run(constants.testcase,null, constants.environment, constants.issue_key,"", "", "");
		JavascriptExecutor js31 = (JavascriptExecutor) driver;
		HashMap<String, String> scrollObject31 = new HashMap<String, String>();
		scrollObject31.put("direction", "up");
		js31.executeScript("mobile: swipe", scrollObject31);// swipe -up or scroll- down

		System.out.println("Performing click on receive Receiver Scenario !!!");
		IOSElement enter_details = driver.findElement(Receive_button);
		enter_details.click();
		
		System.out.println("Landed on Receive waste Details Screen Receiver Scenario !!!");
		new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(Permission_site)));
		IOSElement perm_site = driver.findElement(Permission_site);
		perm_site.click();
		
		new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(click_empty_table)));
		IOSElement opt_sel = driver.findElement(click_empty_table);
		opt_sel.click();
		
		new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(click_continue)));
		IOSElement click_con = driver.findElement(click_continue);
		click_con.click();
		
		new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//XCUIElementTypeStaticText[@label='Amount of waste']"))));
		IOSElement amnt_wste = driver.findElement(amount_waste);
		amnt_wste.sendKeys("1000");
		
		driver.findElement(By.xpath("//XCUIElementTypeStaticText[@label='Unit of waste']")).click();
		new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//XCUIElementTypeStaticText[@label='Unit of waste']"))));
		IOSElement unt_wste = driver.findElement(unit_waste);
		unt_wste.click();
		
		IOSElement c_done = driver.findElement(click_done);
		c_done.click();
		
		JavascriptExecutor js32 = (JavascriptExecutor) driver;
		HashMap<String, String> scrollObject32 = new HashMap<String, String>();
		scrollObject32.put("direction", "up");
		js32.executeScript("mobile: swipe", scrollObject32);
		
		new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(click_submit)));
		IOSElement c_submit = driver.findElement(click_submit);
		
				
		CommonUtils.synthetics("1","start", user_role, user_role, 10000);
		c_submit.click();
	      
	      new WebDriverWait(driver, 60).until(ExpectedConditions.invisibilityOf(driver.findElement(accepting_progress)));
	      //new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//XCUIElementTypeImage[@label='Success']"))));
	      new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(receive_waste_success)));
	    CommonUtils.synthetics("1","stop", user_role, user_role, 10000);
	    
	    if(super.responseStatus.equalsIgnoreCase("pass")){ 
			 
			 System.out.println("### Sending Passed status to Vansah ###\n"+user_role + super.responseTime);
	    	  vj.add_test_log(2,user_role + super.responseTime,1,0,"GDS-336", "", true, driver);
	      }
	      else {
	    	  System.out.println("### Sending Failed status to Vansah ###\n"+user_role + super.responseTime);
	    	  vj.add_test_log(1,user_role + super.responseTime,1,0,"GDS-336", "", true, driver);
	      }
		
		
		
		
		
		
		
		
		
	
	}
}
