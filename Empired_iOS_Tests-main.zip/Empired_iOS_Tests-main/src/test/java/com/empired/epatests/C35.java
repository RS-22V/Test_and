package com.empired.epatests;

import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.empired.initiate.CommonUtils;
import com.empired.initiate.constants;
import com.empired.initiate.vansahjira;

import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
//import io.appium.java_client.android.IOSElement;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.touch.offset.PointOption;

public class C35 extends CommonUtils {
	
	private IOSDriver<IOSElement> driver;
	//private WebDriver driver;
	private WebDriverWait wait ;
	vansahjira vj= new vansahjira();
	By enter_vehicle_details = By.xpath("//XCUIElementTypeButton[@label=\"Enter vehicle details\"]");
	
	//By enter_vehicle_details = By.xpath("//android.widget.Button[@text='Enter vehicle details']");
	//Index	0
	//	Package	au.gov.vic.epa.tracker
	//	Class	android.widget.EditText
	//	Text	Waste record ID
	//scroll through -driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"any text"));");
	//or 
	
		
	By tranport_details_title = By.xpath("//XCUIElementTypeStaticText[@label=\"Transport details\"]");
	JavascriptExecutor js = (JavascriptExecutor) driver;  //pass the element to scroll
	//  /parent::XCUIElementTypeOther
	
	By vehicle_registration_number = By.xpath("//XCUIElementTypeStaticText[@label='Vehicle registration number']");// - //parent::XCUIElementTypeOther
	
	By vehicle_registration_number2 = By.xpath("//XCUIElementTypeStaticText[@label='Vehicle registration number']//parent::XCUIElementTypeOther//parent::XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTextField");
	//XCUIElementTypeStaticText[@label='Vehicle registration number']//parent::XCUIElementTypeOther//parent::XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTextField
	///XCUIElementTypeOther/XCUIElementTypeTextField

	By checkbox = By.xpath("//XCUIElementTypeOther[@label='I declare that I know how to lawfully and safely transport this waste']");
	
	By update_vehicle = By.xpath("//XCUIElementTypeButton[@label='Update vehicle details']");
	
	By pickup_waste = By.xpath("//XCUIElementTypeButton[@label='Pick up waste']");
	
	By receive_waste_title = By.xpath("//XCUIElementTypeStaticText[@label='Receive waste to transport']");
	
	By amount_waste = By.xpath("//XCUIElementTypeStaticText[@label='Amount of waste']//parent::XCUIElementTypeOther//parent::XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTextField");
	
	By unit_waste = By.xpath("//XCUIElementTypeStaticText[@label='Unit of waste']//parent::XCUIElementTypeOther//parent::XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeButton");//XCUIElementTypeButton[@value='Please select']");
	
	//By option_unit_waste = By.id("android:id/alertTitle");
	
	//By select_litres = By.xpath("//android.widget.EditText[@text='Litres']");
	
	By click_done = By.xpath("//XCUIElementTypeButton[@label='Done']");
	
	By click_title = By.xpath("//XCUIElementTypeStaticText[@label='Receive waste to transport']");
	
	By click_submit = By.xpath("//XCUIElementTypeButton[@label='Submit']");
	
	By indicator_icon =  By.xpath("//XCUIElementTypeActivityIndicator[@label='In progress']");
	
	By success_image =  By.xpath("//XCUIElementTypeStaticText[@label='Waste picked up']");
	
	
	
	//(AndroidDriver<IOSElement>)
	public C35(IOSDriver<IOSElement> driver) {
	  this.driver = driver;
		
	}
	
	
	public void measureResponseTimeSearch(String user_role, String waste_record_id) throws Exception {
		
		//search_data = By.xpath("//android.widget.TextView[@text="+waste_record_id+"]");
		//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		vj.add_test_run(constants.testcase,null, constants.environment, constants.issue_key,"", "", "");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		HashMap<String, String> scrollObject = new HashMap<String, String>();
		scrollObject.put("direction", "up");
		js.executeScript("mobile: swipe", scrollObject);// swipe -up or scroll- down

		System.out.println("Performing click on enter vehicle details Driver Scenario !!!");
		IOSElement enter_details = driver.findElement(enter_vehicle_details);
		enter_details.click();
		
		System.out.println("Landed on Transport Details Screen Driver Scenario !!!");
		new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(tranport_details_title)));
	
		//IOSElement reg_num = driver.findElement(vehicle_registration_number);
		//reg_num.sendKeys("Test123");
		//System.out.println("Done");
		new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(vehicle_registration_number2)));
		IOSElement reg_num = driver.findElement(vehicle_registration_number2);
		reg_num.sendKeys("Test123");
		
		new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(vehicle_registration_number)));
		IOSElement reg_num1 = driver.findElement(vehicle_registration_number);
		reg_num1.click();
		
		
		JavascriptExecutor js1 = (JavascriptExecutor) driver;
		HashMap<String, String> scrollObject1 = new HashMap<String, String>();
		scrollObject1.put("direction", "up");
		js1.executeScript("mobile: swipe", scrollObject1);
		
		new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(checkbox)));
		IOSElement click_box = driver.findElement(checkbox);
		click_box.click();
		
		System.out.println("Performing click_oper on Update vehicle Driver Scenario !!!");
		new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(update_vehicle)));
		IOSElement upd_vehicleB = driver.findElement(update_vehicle);
		upd_vehicleB.click();
		
		//Thread.sleep(2500);

		//comment it when using with enter vehicle
		//driver.findElement(By.xpath("//XCUIElementTypeStaticText[@label='"+waste_record_id+"']"));
		driver.findElement(By.xpath("//XCUIElementTypeStaticText[@label='"+waste_record_id+"']")).click();
		
		
		
		JavascriptExecutor js12 = (JavascriptExecutor) driver;
		HashMap<String, String> scrollObject12 = new HashMap<String, String>();
		scrollObject12.put("direction", "up");
		js12.executeScript("mobile: swipe", scrollObject12);
		js12.executeScript("mobile: swipe", scrollObject12);
		js12.executeScript("mobile: swipe", scrollObject12);
		js12.executeScript("mobile: swipe", scrollObject12);
		
		new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(pickup_waste)));
		IOSElement pickup_wasteB = driver.findElement(pickup_waste);
		pickup_wasteB.click();
		
		new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(receive_waste_title)));
		
		IOSElement amt_waste = driver.findElement(amount_waste);
		amt_waste.sendKeys("1234");
		
		driver.findElement(By.xpath("//XCUIElementTypeStaticText[@label='Amount of waste']")).click();
		// By.xpath("//XCUIElementTypeStaticText[@label='Amount of waste']
		
		Thread.sleep (2000);
		
		new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(unit_waste)));
		IOSElement unit_waste_dd = driver.findElement(unit_waste);
		unit_waste_dd.click();
		
		new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(click_done)));
		IOSElement click_done_lit = driver.findElement(click_done);
		click_done_lit.click();
		
		IOSElement click_title_d = driver.findElement(click_title);
		click_title_d.click();
		
		JavascriptExecutor js13 = (JavascriptExecutor) driver;
		HashMap<String, String> scrollObject13 = new HashMap<String, String>();
		scrollObject13.put("direction", "up");
		js13.executeScript("mobile: swipe", scrollObject13);// swipe -up or scroll- down
		
		
		new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(click_submit)));
		IOSElement click_sub = driver.findElement(click_submit);
		
		
		CommonUtils.synthetics("1","start", user_role, user_role, 10000);
		click_sub.click();
	      
	      new WebDriverWait(driver, 60).until(ExpectedConditions.invisibilityOf(driver.findElement(indicator_icon)));
	      new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//XCUIElementTypeImage[@label='Success']"))));
	      new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(success_image)));
	    CommonUtils.synthetics("1","stop", user_role, user_role, 10000);
	    
	    if(super.responseStatus.equalsIgnoreCase("pass")){ 
			 
			 System.out.println("### Sending Passed status to Vansah ###\n"+user_role + super.responseTime);
	    	  vj.add_test_log(2,user_role + super.responseTime,1,0,"GDS-336", "", true, driver);
	      }
	      else {
	    	  System.out.println("### Sending Failed status to Vansah ###\n"+user_role + super.responseTime);
	    	  vj.add_test_log(1,user_role + super.responseTime,1,0,"GDS-336", "", true, driver);
	      }
		
		
		System.out.println("Done Executing Driver Scenario !!!");
		
		driver.findElement(By.xpath("//XCUIElementTypeButton[@label='Return to homepage']")).click();
		
		JavascriptExecutor js14 = (JavascriptExecutor) driver;
		HashMap<String, String> scrollObject14 = new HashMap<String, String>();
		scrollObject14.put("direction", "down");
		js13.executeScript("mobile: swipe", scrollObject14);// swipe -up or scroll- down
		
		System.out.println("Swiping down !!");
		new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//XCUIElementTypeOther[@label='Search button']"))));
		System.out.println("Search Complete ready for next-step");
		
		
		
		
		//WebElement 
//		JavascriptExecutor js = (JavascriptExecutor) driver;
//		HashMap<String, String> scrollObject = new HashMap<String, String>();
//		scrollObject.put("direction", "down");
//		scrollObject.put("element", ((RemoteWebElement) enter_vehicle_details).getId());
//		
//		js.executeScript("mobile: scroll", scrollObject);
//		
//		WebElement resource = driver.findElement(By.xpath("//XCUIElementTypeStaticText[@value='Pick up Address']")); ;
//	    WebElement openid = driver.findElement(By.xpath("//XCUIElementTypeButton[@label='Enter vehicle details']"));
//	    TouchAction action = new TouchAction(driver);
//	    action.press((PointOption) resource).moveTo((PointOption) openid).release();
//	    action.perform();
		
	    
//		RemoteWebElement element = (RemoteWebElement)driver.findElement(By.xpath("//XCUIElementTypeButton[@label='Enter vehicle details']"));
//		System.out.println("Element"+element);
//		String elementID = element.getId();
//		HashMap<String, String> scrollObject = new HashMap<String, String>();
//		scrollObject.put("element", elementID); 
//		scrollObject.put("direction", "down");
//		driver.executeScript("mobile:scroll", scrollObject);
//			
		

		//driver.findElementByIosUIAutomation("new UiScrollable(new UiSelector()).scrollIntoView(text(\"Update vehicle details\"))");
		//driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"Update vehicle details\"));");
		//driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"I declare that I know how to lawfully and safely transport this waste. Double tap to activate\"));");
		
		
		//driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"Update vehicle details\"));");
		
//		
//		Thread.sleep(3000);
//		
//		//new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//android.widget.TextView[@text='"+waste_record_id+"']"))));
//		
//		
//		
//		//driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"Pick up waste\"));"); // scrolling to enter vehicle details
//		
//		
//		

//		

////		driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"Litres\"));");
////		IOSElement select_litres_option = driver.findElement(select_litres);
////		select_litres_option.click();
//		

//		
//		
//		driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"Submit\"));");
//		IOSElement click_sub = driver.findElement(click_submit);
//		
//		
//		CommonUtils.synthetics("1","start", user_role, user_role, 10000);
//		click_sub.click();
//	      
//	      new WebDriverWait(driver, 60).until(ExpectedConditions.invisibilityOf(driver.findElement(progressbar)));
//	      new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(check_success)));
//	    CommonUtils.synthetics("1","stop", user_role, user_role, 10000); 
		 
		
		
		
		
		
		
//		new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(enter_vehicle_details)));
//		js.executeScript("arguments[0].scrollIntoView()[0];", enter_vehicle_details);
//		new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(enter_vehicle_details)));
//		((JavascriptExecutor) driver).executeScript("arguments[0].click();", enter_vehicle_details);
//		if (((WebElement) enter_vehicle_details).isEnabled() && ((WebElement) enter_vehicle_details).isDisplayed()) {
//			System.out.println("Clicking on element with using java script click");
//
//			((JavascriptExecutor) driver).executeScript("arguments[0].click();", enter_vehicle_details);
//		} else {
//			System.out.println("Unable to click on element");
//		}
		//js.executeScript("arguments[0].scrollIntoView()[0].click();", enter_vehicle_details);
		//MobileElement entering_details = driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"Australia\"));");
		//entering_details.click();
		
//		new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(tranport_details_title)));
//		
//		IOSElement reg_num = driver.findElement(vehicle_registration_number);
//		reg_num.sendKeys("Test123");
		
		
//		IOSElement sfield = driver.findElement(search_field);
//		sfield.sendKeys(waste_record_id);
//		
//		//new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(wait_activerecord)));
//		
//		IOSElement sbutton = driver.findElement(search_button);
//		sbutton.click();
//		CommonUtils.synthetics("1","start", user_role, "Driver_SearchButton_Android", 10000);
//		
//		//search_data = By.xpath("//android.widget.TextView[@text='"+waste_record_id+"']");
//		new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//android.widget.TextView[@text='"+waste_record_id+"']"))));
//		CommonUtils.synthetics("1","stop", user_role, "Driver_SearchButton_Android", 10000);
//		
		//System.out.println(driver.getPageSource());
		//B0Y-540105-Q8R
		
	}
	

}
